<template>
  <div class="">
    <h1>This is Home page</h1>
  </div>
</template>

<script>
export default {
  name: "login-page",
};
</script>
